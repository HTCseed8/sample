/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.htc.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;

@WebListener()
public class MyListner implements HttpSessionAttributeListener {

	@Override
	public void attributeAdded(HttpSessionBindingEvent event) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void attributeRemoved(HttpSessionBindingEvent event) {
		String s = event.getValue().toString();

		try {
			Connection con = DbConnection.connect();

			PreparedStatement psmt = con.prepareStatement("delete from ed where empid=?");
			psmt.setString(1, s);
			int i = psmt.executeUpdate();
			if (i > 0) {
				System.out.println(s + "deleted");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void attributeReplaced(HttpSessionBindingEvent event) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

}
