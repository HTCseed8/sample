/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.htc.service;

import java.sql.Connection;
import java.sql.DriverManager;


public class DbConnection {
    private static Connection con;
	 public static Connection connect() throws Exception{
		 Class.forName("org.postgresql.Driver");
		 con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres","postgres","password@123");
		 
		 return con;
	 }
}
