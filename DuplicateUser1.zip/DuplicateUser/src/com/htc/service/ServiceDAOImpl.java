/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.htc.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class ServiceDAOImpl {

	public boolean InsertEmpl(String empid, String name, String emailId, String password) {

		try {
			Connection con = DbConnection.connect();
			PreparedStatement psmt = con.prepareStatement("insert into employee values(?,?,?,?)");
			psmt.setString(1, empid);
			psmt.setString(2, name);
			psmt.setString(3, emailId);
			psmt.setString(4, password);
			int i = psmt.executeUpdate();
			if (i > 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;

	}

	public boolean checkEmployeeExist(String empid, String password) {
		try {
			Connection con = DbConnection.connect();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select empid from employee");
			while (rs.next()) {
				if (rs.getString("empid").equals(empid))
					return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean duplicacyCheck(String empid, String name) {
		try {
			Connection con = DbConnection.connect();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select empid from ed");
			while (rs.next()) {
				if (rs.getString("empid").equals(empid))
					return false;
			}
			PreparedStatement psmt = con.prepareStatement("insert into ed values(?,?)");
			psmt.setString(1, empid);
			psmt.setString(2, name);
			int i = psmt.executeUpdate();
			if (i > 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
}
