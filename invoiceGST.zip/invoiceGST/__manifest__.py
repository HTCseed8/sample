{
    'name' : 'GST Invoice',
    'version': '1.0',
	'category': 'Sales',
    'complexity': 'easy',
    'description': "Allows user to select product category wise and print the bill including GST",
    'depends': ['base', 'web'],
    'data': [
        'views/product_details.xml',
        
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}