from odoo import api, fields, models, _
from dateutil.relativedelta import relativedelta

class orderdetails(models.Model):
    _name='invoiceGST.orderdetails'
	
	order_id=fields.Char(string='Order Code', size=32, requiered=True)
	order_type=fields.Char(string='Order Type', size=64, requiered=True)
	order_date=fields.Date(string='Order Date', size=32, requiered=True)
	category_id=One2many('invoiceGST.category', string='Category Code', requiered=True)
	product_id=One2many('invoiceGST.product', string='Product Code', requiered=True)

class category(models.Model):
    _name='invoiceGST.category'
	
	category_id=fields.Char(string='Category Code', size=32, requiered=True)
	category_name=fields.Char(string='Category Name', size=64, requiered=True)
	category_type=fields.Char(string='category Type', size=64, requiered=True)
	category_description=fields.Char(string='category Description', size=128)
	
class product(models.Model):
    _name='invoiceGST.product'
	
	product_id=fields.Char(string='Product Code', size=32, requiered=True)
	product_name=fields.Char(string='Product Name', size=32, requiered=True)
	category_id=One2many('invoiceGST.category', string='Ctaegory Code', requiered=True)
	product_type=fields.Char(string='Product Type', size=64, requiered=True)
	product_description=fields.Char(string='Product Description', size=64, requiered=True)
	manufactured_date=fields.Date(String='Manufactured Date', requiered=True)
	expiery_date=fields.Date(string='Expiery Date', requiered=True)
	qty_on_hand=fields.Integer(string='Quantity on Hand', size=32, requiered=True)
	product_price=fields.Integer(string='Product Price', size=32, requiered=True)
	product_tax_id=Many2one('invoiceGST.taxdetails', string='GST Code', requiered=True)
	
class taxdetails(models.Model):
    _name='invoiceGST.taxdetails'
	
	product_tax_id=fields.Integer(string='GST Code', size=32, requiered=True)
	product_tax_value=fields.Char(string='GST Value', size=32, requiered=True)
	 
