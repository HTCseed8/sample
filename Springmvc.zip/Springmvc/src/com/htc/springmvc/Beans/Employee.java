package com.htc.springmvc.Beans;


public class Employee {
	
	private String empCode;
	private String  empName;
	private String emailId;
	private double empSalary;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(String empCode, String empName, String emailId, double empSalary) {
		super();
		this.empCode = empCode;
		this.empName = empName;
		this.emailId = emailId;
		this.empSalary = empSalary;
	}

	public String getEmpCode() {
		return empCode;
	}

	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	@Override
	public String toString() {
		return "Employee [empCode=" + empCode + ", empName=" + empName + ", emailId=" + emailId + ", empSalary="
				+ empSalary + "]";
	}
	
	
}
