package com.htc.springmvc.Dao;

import com.htc.springmvc.Beans.Employee;

public interface EmployeeDAO {
	
	public Employee addEmployee( Employee emp);
	
}
