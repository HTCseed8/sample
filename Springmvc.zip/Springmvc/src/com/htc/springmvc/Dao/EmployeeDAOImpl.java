package com.htc.springmvc.Dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.htc.springmvc.Beans.Employee;

@Repository("EmployeeDAO")
public class EmployeeDAOImpl implements EmployeeDAO {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}



	@Override
	public Employee addEmployee(Employee emp) {
		
		int i=jdbcTemplate.update("INSERT INTO employee VALUES (?, ?)",emp.getEmpCode(),emp.getEmpName());
		if(i>0)		  
		return emp;
		return null;
	}

}
