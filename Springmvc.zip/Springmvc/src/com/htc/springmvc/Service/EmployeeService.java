package com.htc.springmvc.Service;

import org.springframework.stereotype.Service;

import com.htc.springmvc.Beans.Employee;


public interface EmployeeService {
	
		public Employee saveEmployee(Employee emp);
}
