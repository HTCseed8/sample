package com.htc.springmvc.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.htc.springmvc.Beans.Employee;
import com.htc.springmvc.Dao.EmployeeDAO;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	EmployeeDAO empDao;
	public EmployeeDAO getEmpDao() {
		return empDao;
	}
	public void setEmpDao(EmployeeDAO empDao) {
		this.empDao = empDao;
	}


	@Override
	public Employee saveEmployee(Employee emp) {
		
		return empDao.addEmployee(emp);
	}
	
	

}
