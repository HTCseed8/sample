package com.htc.springmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.htc.springmvc.Beans.Employee;
import com.htc.springmvc.Service.EmployeeService;

@Controller
public class WelcomeController {
	
	@Autowired
	EmployeeService employeeService;
	
	public EmployeeService getEmployeeService() {
		return employeeService;
	}

	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	@RequestMapping(method=RequestMethod.GET, value="/welcome")
	
	public String welcome() {
		return "welcome";  //control string.
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/Regs")
	
		public ModelAndView Regs() {
			Employee emp=new Employee();
			emp.setEmpName("Soham");
			emp.setEmpSalary(2202578);
			Employee emp1=employeeService.saveEmployee(emp);
			ModelAndView mv = new ModelAndView("login", "emp", emp1);
			return mv;
		
	}

}
