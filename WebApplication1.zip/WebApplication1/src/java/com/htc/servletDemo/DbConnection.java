/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.htc.servletDemo;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Suman Chatterjee
 */
public class DbConnection {
    private static Connection con;
	 public static Connection connect() throws Exception{
		 Class.forName("org.postgresql.Driver");
		 con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/Employee","postgres","1234");
		 return con;
	 }
}
