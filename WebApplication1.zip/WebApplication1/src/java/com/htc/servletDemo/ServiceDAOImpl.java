/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.htc.servletDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

/**
 *
 * @author Suman Chatterjee
 */
public class ServiceDAOImpl {
    public boolean checkemployee(String password,String name) throws SQLException, Exception{
       
        try{
        Connection con=DbConnection.connect();
        Statement st=con.createStatement();
       
	ResultSet rs=st.executeQuery("select password from employee");
	while(rs.next()) {
	if(rs.getString("password").equalsIgnoreCase(password)){
            
	return true;
	}
        }			
        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
        
    }
    
    public boolean duplicateEmp(String name,String password){
        try{
            Connection con=DbConnection.connect();
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery("select username from empdup");
        while(rs.next()){
            if(rs.getString("username").equalsIgnoreCase(name))
                return false;
        }
            PreparedStatement psmt=con.prepareStatement("insert into empdup values(?,?)");
            psmt.setString(1, name);
            psmt.setString(2,password);
            int i=psmt.executeUpdate();
            if(i>0)
        return true;
        }catch(Exception e){
            e.printStackTrace();
        }
      return false;  
    }
    
    
}
