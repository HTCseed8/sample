/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.htc.servletDemo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.*;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 *
 * @author Suman Chatterjee
 */
@WebListener()
public class MyListener implements  HttpSessionAttributeListener {

    @Override
    public void attributeAdded(HttpSessionBindingEvent event) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void attributeRemoved(HttpSessionBindingEvent event) {
        
        String s=event.getValue().toString();
        
        System.out.println(s);
        try{
         Connection con=DbConnection.connect();
        //Statement st=con.createStatement
        PreparedStatement psmt=con.prepareStatement("delete from empdup where username=?");
        psmt.setString(1,s);
        int i=psmt.executeUpdate();
        if(i>0){
            System.out.println(s+ "deleted");
        }
    }catch(Exception e){
        e.printStackTrace();
    }
    }

    @Override
    public void attributeReplaced(HttpSessionBindingEvent event) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
  
    
}
